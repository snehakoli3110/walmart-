package com.niit.WalmartWishlist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalmartWishlistApplicationTests {

	@Test
	void contextLoads() {
	}

}
