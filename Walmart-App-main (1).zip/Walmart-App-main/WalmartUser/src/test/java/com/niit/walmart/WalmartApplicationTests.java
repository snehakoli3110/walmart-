package com.niit.walmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WalmartApplicationTests {

	@Test
	void contextLoads() {
	}

}
