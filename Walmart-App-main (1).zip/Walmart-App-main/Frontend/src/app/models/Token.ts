export class Token {
    token : string
}