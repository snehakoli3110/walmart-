export class productDetails {
    id: Number
    img_url?: string
    price: string;
    quantity: number;
    title: string;
    user_id: string;
    exists: boolean;
}