export class User {
    id : Number
    username : string
    password : string
    email : string
    name : string
    address : string
    phone : string
    cartItems : [any]
}